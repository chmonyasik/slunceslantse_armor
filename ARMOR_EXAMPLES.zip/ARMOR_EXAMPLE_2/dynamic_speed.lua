-- version 1.2

-- HOW TO USE:
-- line up your animations with the markers in the provided bbmodel
-- the walkguide in the bbmodel moves at the speed that blocks would be moving under the player
-- this script will then dynamically adjust the speed of the animations based on the player's current speed

-- you can paste the walkguide and animations into a seperate bbmodel if you'd like

-- things to note:
-- climb/crawl are basically vertical movement - minecraft roates the playermodel 90d to face the ground
-- crouch puts the bottom of the model 2px into the ground, so the walkguide is raised to show the actual ground level
-- if you turn on hitboxes you can see the notches of the walkguide in-game while moving
-- you may want to delete the walkguide after you are done to save space

-- path to the bbmodel with the animations to adjust
-- expected animations (all are optional):
-- walk
-- sprint
-- crouchwalk
-- climb
-- crawl

-- keep track of time in air to more accurately detect falls
local airTime = 0

-- keep track of stride state for air animations
local strideStarted = true

-- keep track of ground state to detect jumps or landing
wasGround = false

-- feature toggles
-- slows down the animations when in the air, giving a sort of leaping animation without manually animating anything
local airSlowdown = true
-- playing animations (can be removed if using EzAnims or another method of playing animations)
local playAnimations = true
local wasMoving = false

local isLoaded

function events.entity_init()
	isLoaded = player:isLoaded()
end

function events.tick()
    local vel = player:getVelocity()
    local pose = player:getPose()
    local yaw = player:getBodyYaw()
    local ground = player:isOnGround()
    
	if isLoaded then
		-- if your model is scaled up/down, divide this number by the multiplier you scaled the model by
		-- eg. if model is scaled to 50% (half size), divide this by 0.5 (which will double the speed)
		
		-- slows down the animations when in the air, giving a sort of leaping animation without manually animating anything
		if airSlowdown then
			-- check if the player is on the ground
			if not ground then
				-- in-air
				airTime = airTime + 1
			end
			-- check grounded state change
			if ground ~= wasGround then
				wasGround = ground
				
				local sitting = player:getVehicle() ~= nil or pose == "SITTING"
				
				-- check if in air, or just landed
				if not ground then
					-- reset stride and airtime states
					strideStarted = false
					airTime = 0
				elseif not sitting and airTime > 6 and pose ~= "SLEEPING" then
					-- a landing occured, can run some code here like playing an animation
					--if animations.model.land then
						animations.model.land:stop():play()
					--end
				end
			end
			-- check if both in air and a stride has started
			if not ground and strideStarted then
				-- drastically slow down movement animations
				vel = vel * 0.2
			end
		end
		
		-- convert velocity into directional components
		-- vel calculations stolen from squassets
		local forwardVel = vel:dot(vectors.angleToDir(0, yaw))
        local horizontalVel = vel.xz:length() * 20 -- convert to m/s

		-- check moving backwards - if moving backwards reverse direction
		-- remove this if you have seperate backwards animations
		local dirMult = forwardVel < 0 and -1 or 1
        
		-- divide animation speed by the velocity they represent to sync up
		local walkspeed = horizontalVel / 4.317 * dirMult
		local sprintspeed = horizontalVel / 5.612 * dirMult
		local crouchspeed = horizontalVel / 1.3 * dirMult
		local climbspeed = vel.y * 20 / 2.35
		
		-- playing animations (you can delete this section if you don't need it)
		if playAnimations then
			 -- get states
			local moving = horizontalVel > 0.05
			
			local sprinting = player:isSprinting()
			--local crouching = player:isCrouching()
			local crawling = pose == "SWIMMING"
			--local climbing = player:isClimbing()
			
			if animations.model.walk then
			    local movingNow = moving and not sprinting and not crouching and not crawling
			
                if movingNow then --add not in water
                    animations.model.walk:playing(true):speed(walkspeed)
                else
                    if wasMoving then                
                        animations.model.walk:stop()
                    end
                end

                if movingNow and not wasMoving then animations.model.walk:time(math.random() < 0.5 and 0 or 0.375) end
                
                wasMoving = movingNow
			end
			
			if animations.model.sprint then
				animations.model.sprint:playing(moving and sprinting and not crouching):speed(sprintspeed)
			end
			--[[
			if anim.crawl then
				anim.crawl:playing(crawling):speed(crouchspeed)
			end
			if anim.climb then
				anim.climb:playing(climbing):speed(climbspeed)
			end
			]]
		end
	end
end

function strideStart()
	strideStarted = true
end
