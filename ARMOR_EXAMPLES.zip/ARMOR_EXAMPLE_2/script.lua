--hide vanilla model
vanilla_model.PLAYER:visible(false)

animations.model.idle:play()

require("GSAnimBlend")
animations.model.walk:blendTime(1,4)
animations.model.sprint:blendTime(1,4)

local root = models.model.root
local Torso = root.Torso

local Head = Torso.BASE_Head
local Body = Torso.BASE_Body
local LeftArm = Torso.BASE_LeftArm
local RightArm = Torso.BASE_RightArm
local LeftLeg = root.BASE_LeftLeg
local RightLeg = root.BASE_RightLeg

local V_HAT = vanilla_model.HAT
local V_HEAD = vanilla_model.HEAD
local V_BODY = vanilla_model.BODY
local V_L_ARM = vanilla_model.LEFT_ARM
local V_R_ARM = vanilla_model.RIGHT_ARM
local V_L_LEG = vanilla_model.LEFT_LEG
local V_R_LEG = vanilla_model.RIGHT_LEG

---

local gaze = require("Gaze")
local mainGaze = gaze:newGaze(Head)

gaze:unsetPrimary()

mainGaze.config.doRandomGaze = false
mainGaze.config.actionCooldown = 20
mainGaze.config.turnDampen = 0.9

---

local smoothie = {}
function smoothie:newSmoothHead(modelPart)
    -- Checking the validity of the parameter

    

    -- Setting up some variables
    local interface = {}
    local headModelPart = modelPart
    local strength = 1
    local speed = 1
    local tiltMultiplier = 1
    local keepVanillaPosition = true
    local headRotPrevFrame = vec(0, 0, 0)

    -- Head rotation processor
    events.RENDER:register(function(delta, context)
        -- Checking the need to process the head rotation
        if not player:isLoaded() then return end
        if not (context == "RENDER" or context == "FIRST_PERSON" or context == "MINECRAFT_GUI") then return end

        -- Math part
        local headRot = math.lerp(
            headRotPrevFrame,
            ((vanilla_model.HEAD:getOriginRot() + 180) % 360 - 180) * strength,
            math.min(8 / math.max(client:getFPS(), 1) * speed, 1)
        )
        headRot[3] = math.lerp(
            headRotPrevFrame[3],
            2.5 * ((vanilla_model.HEAD:getOriginRot() + 180) % 360 - 180)[2] / 50 * tiltMultiplier,
            math.min(8 / math.max(client:getFPS(), 1) * speed, 1)
        )

        -- Applying new head rotation
        headModelPart:offsetRot(headRot)
        headRotPrevFrame = headRot

        -- Fixing crouching pose
        if keepVanillaPosition then headModelPart:setPos(-vanilla_model.HEAD:getOriginPos()) end
    end, "Smoothie.SmoothHead")

    --[[
        Interface
    ]]--
    function interface:setStrength(value)
        if value == nil then value = 1 end
        assert(type(value) == "number", "Invalid argument to function setStrength. Expected number, but got " .. type(value))
        strength = value

        return interface -- Returns interface for chaining
    end
    function interface:strength(value) return interface:setStrength(value) end  -- Alias

    function interface:setSpeed(value)
        if value == nil then value = 1 end
        assert(type(value) == "number", "Invalid argument to function setSpeed. Expected number, but got " .. type(value))
        speed = value

        return interface -- Returns interface for chaining
    end
    function interface:speed(value) return interface:setSpeed(value) end  -- Alias

    function interface:setTiltMultiplier(value)
        if value == nil then value = 1 end
        assert(type(value) == "number", "Invalid argument to function setTiltMultiplier. Expected number, but got " .. type(value))
        tiltMultiplier = value

        return interface -- Returns interface for chaining
    end
    function interface:tiltMultiplier(value) return interface:setTiltMultiplier(value) end  -- Alias

    function interface:setKeepVanillaPosition(state)
        if state == nil then state = true end
        assert(type(state) == "boolean", "Invalid argument to function setKeepVanillaPosition. Expected boolean, but got " .. type(state))
        keepVanillaPosition = state

        return interface -- Returns interface for chaining
    end
    function interface:keepVanillaPosition(state) return interface:setKeepVanillaPosition(state) end -- Alias

    return interface
end

smoothie:newSmoothHead(Torso):setKeepVanillaPosition(true):setSpeed(0.3)
--smoothie:newSmoothHead(Head):setKeepVanillaPosition(true)
