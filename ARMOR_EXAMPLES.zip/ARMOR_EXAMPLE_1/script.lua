--hide vanilla model
vanilla_model.PLAYER:visible(false)

local mainPage = action_wheel:newPage()
action_wheel:setPage(mainPage)

mainPage:newAction()
    :title("TEST")
    :item("spruce_stairs")
    :onToggle(function(state)
        animations.model.sit:playing(state)
    end)
    
animations.model.base:play()

local root = models.model.root
local Torso = root.Torso
local _LeftLeg_Pivot = root._LeftLeg_Pivot
local _RightLeg_Pivot = root._RightLeg_Pivot

local Head = Torso.BASE_Head

local smoothie = {}
function smoothie:newSmoothHead(modelPart)
    -- Checking the validity of the parameter
    assert(type(modelPart) == "ModelPart", "Invalid argument to function newSmoothHead. Expected ModelPart, but got " .. type(modelPart))
    modelPart:setParentType("NONE") -- Preparing modelPart

    -- Setting up some variables
    local interface = {}
    local headModelPart = modelPart
    local strength = 1
    local speed = 1
    local tiltMultiplier = 1
    local keepVanillaPosition = true
    local headRotPrevFrame = vec(0, 0, 0)

    -- Head rotation processor
    events.RENDER:register(function(delta, context)
        -- Checking the need to process the head rotation
        if not player:isLoaded() then return end
        if not (context == "RENDER" or context == "FIRST_PERSON" or context == "MINECRAFT_GUI") then return end

        -- Math part
        local headRot = math.lerp(
            headRotPrevFrame,
            ((vanilla_model.HEAD:getOriginRot() + 180) % 360 - 180) * strength,
            math.min(8 / math.max(client:getFPS(), 1) * speed, 1)
        )
        headRot[3] = math.lerp(
            headRotPrevFrame[3],
            2.5 * ((vanilla_model.HEAD:getOriginRot() + 180) % 360 - 180)[2] / 50 * tiltMultiplier,
            math.min(8 / math.max(client:getFPS(), 1) * speed, 1)
        )

        -- Applying new head rotation
        headModelPart:setOffsetRot(headRot)
        headRotPrevFrame = headRot

        -- Fixing crouching pose
        if keepVanillaPosition then headModelPart:setPos(-vanilla_model.HEAD:getOriginPos()) end
    end, "Smoothie.SmoothHead")

    --[[
        Interface
    ]]--
    function interface:setStrength(value)
        if value == nil then value = 1 end
        assert(type(value) == "number", "Invalid argument to function setStrength. Expected number, but got " .. type(value))
        strength = value

        return interface -- Returns interface for chaining
    end
    function interface:strength(value) return interface:setStrength(value) end  -- Alias

    function interface:setSpeed(value)
        if value == nil then value = 1 end
        assert(type(value) == "number", "Invalid argument to function setSpeed. Expected number, but got " .. type(value))
        speed = value

        return interface -- Returns interface for chaining
    end
    function interface:speed(value) return interface:setSpeed(value) end  -- Alias

    function interface:setTiltMultiplier(value)
        if value == nil then value = 1 end
        assert(type(value) == "number", "Invalid argument to function setTiltMultiplier. Expected number, but got " .. type(value))
        tiltMultiplier = value

        return interface -- Returns interface for chaining
    end
    function interface:tiltMultiplier(value) return interface:setTiltMultiplier(value) end  -- Alias

    function interface:setKeepVanillaPosition(state)
        if state == nil then state = true end
        assert(type(state) == "boolean", "Invalid argument to function setKeepVanillaPosition. Expected boolean, but got " .. type(state))
        keepVanillaPosition = state

        return interface -- Returns interface for chaining
    end
    function interface:keepVanillaPosition(state) return interface:setKeepVanillaPosition(state) end -- Alias

    return interface
end

smoothie:newSmoothHead(Torso):setKeepVanillaPosition(false):setSpeed(0.3)
--smoothie:newSmoothHead(Head):setKeepVanillaPosition(false):setSpeed(0.1)
