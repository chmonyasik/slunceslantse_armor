--hide vanilla model
vanilla_model.PLAYER:visible(false)

local mainPage = action_wheel:newPage()
action_wheel:setPage(mainPage)

mainPage:newAction()        
    :title("TEST")
    :item("spruce_stairs")
    :onToggle(function(state)
        animations.model.sit:playing(state)
    end)
